A Pen created at CodePen.io. You can find this one at https://codepen.io/SebastianOpperman/pen/wZLrQz.

 This is a module for a featured news section of a gaming website. It contains 3 articles and a call-to-action for a signup form.